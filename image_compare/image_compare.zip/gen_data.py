import numpy as np
from PIL import Image
import os
import shutil

data = []
group_ids = []
image_paths = []

for root, dirs, files in os.walk('images/test'):
    for file in files:
        _, group_id = os.path.split(root)
        img = Image.open(os.path.join(root, file)).resize((224, 224))
        data.append(np.array(img))
        group_ids.append(int(group_id))
        image_paths.append(os.path.join(root, file))

data = np.array(data)
group_ids = np.array(group_ids, dtype=np.int32)
data.tofile('test_data.np')
group_ids.tofile('test_group_ids.np')

with open('test_image_list.txt', 'w') as f:
    for image_path in image_paths:
        f.write(image_path + '\n')