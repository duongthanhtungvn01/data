import numpy as np


features = np.fromfile('features_v2.np', dtype=np.float32).reshape((-1, 1024))

image_paths = []

with open('train_image_list.txt') as fid:
    for line in fid:
        image_paths.append(line.strip())

with open('test_image_list.txt') as fid:
    for line in fid:
        image_paths.append(line.strip())

def find_sim(i, thresh=0.5):
    feature0 = features[i]
    sim = []
    for j, feature in enumerate(features):
        if j != i:
            dist = np.linalg.norm(feature - feature0)
            if dist < thresh:
                sim.append((dist, j))
    sim = sorted(sim)
    return [(image_paths[x[1]], x[0]) for x in sim[:5]]
