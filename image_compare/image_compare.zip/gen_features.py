import numpy as np
import random
from keras import backend as K
from keras.models import Model
from keras.layers import Dense, Flatten, Conv2D, MaxPool2D, GlobalAveragePooling2D, Dropout, Lambda, Reshape
from keras.layers.merge import concatenate
from keras.optimizers import SGD
from keras.callbacks import EarlyStopping, ModelCheckpoint
from keras.applications.mobilenet import MobileNet
from keras.models import load_model

img_size = 224
train_factor = 0.8
batch_size = 16 * 3


def _loss_tensor(y_true, y_pred):
    epsilon = 1e-7
    y_pred = K.clip(y_pred, epsilon, 1.0-epsilon)
    loss =  0
    #    
    for i in range(0, batch_size//3):
        q_embedding = y_pred[3*i+0]
        p_embedding = y_pred[3*i+1]
        n_embedding = y_pred[3*i+2]
        D_q_p =  K.sqrt(K.sum((q_embedding - p_embedding)**2))
        D_q_n = K.sqrt(K.sum((q_embedding - n_embedding)**2))
        loss = (loss + D_q_p - D_q_n )
    #        
    return 2 + loss/(batch_size//3)

model = load_model('model_v1_1.335.h5', custom_objects={'_loss_tensor' : _loss_tensor})

train_data = np.fromfile('train_data.np', dtype=np.uint8).reshape((-1, img_size, img_size, 3))
test_data = np.fromfile('test_data.np', dtype=np.uint8).reshape((-1, img_size, img_size, 3))
data = np.concatenate((train_data, test_data))
data = data.astype('float32')/255.0
features = model.predict(data, batch_size=32)
features.tofile('features.np')
